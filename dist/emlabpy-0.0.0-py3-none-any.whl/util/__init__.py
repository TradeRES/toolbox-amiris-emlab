"""
The util package. This package contains all Python files in regard to data organization or SpineDB interactions.
"""