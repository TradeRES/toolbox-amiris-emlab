"""
This file contains all classes that have zonal or geographic properties.

Jim Hommes - 13-5-2021
"""
from emlabpy.domain.import_object import *


class Zone(ImportObject):
    pass


class PowerGridNode(ImportObject):
    pass
