"""
The Domain package contains all definitions of Emlabpy objects, like power plants, producers and more.
"""